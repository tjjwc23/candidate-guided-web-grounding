"""Load the frozen BF16 base model and attach the trainable LoRA adapter."""

import os
import torch

os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("HF_DATASETS_OFFLINE", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

BASE_MODEL = "microsoft/Fara1.5-4B"
BASE_REVISION = "776a33ae5b2ad503796a97ae20fdc66f61d2feea"


def load_model():
    from transformers import AutoProcessor, Qwen3_5ForConditionalGeneration
    from peft import LoraConfig, get_peft_model

    torch.set_num_threads(4)
    torch.manual_seed(42)
    torch.cuda.manual_seed_all(42)
    processor = AutoProcessor.from_pretrained(
        BASE_MODEL, revision=BASE_REVISION, local_files_only=True
    )
    kwargs = dict(
        revision=BASE_REVISION,
        local_files_only=True,
        dtype=torch.bfloat16,
        attn_implementation="sdpa",
        device_map={"": "cuda:0"},
    )
    model = Qwen3_5ForConditionalGeneration.from_pretrained(BASE_MODEL, **kwargs)
    for parameter in model.parameters():
        parameter.requires_grad = False
    targets = [
        n
        for n, _ in model.named_modules()
        if "language_model.layers." in n
        and n.split(".")[-1]
        in ["q_proj", "v_proj", "o_proj", "in_proj_qkv", "out_proj"]
    ]
    model = get_peft_model(
        model,
        LoraConfig(
            r=16,
            lora_alpha=32,
            lora_dropout=0.0,
            target_modules=targets,
            bias="none",
            task_type="CAUSAL_LM",
        ),
    )
    model.gradient_checkpointing_disable()
    model.eval()
    return processor, model

"""Native greedy coordinates and fixed window evidence aggregation."""
import re
from collections import defaultdict
import torch
from grounding.coordinate import encoding
from grounding.coordinate.prefix import COORDINATE_CACHE_PREFIX
from grounding.coordinate.regions import logsumexp_values

def parse_coordinate_tail(text):
    # A single tokenizer token can contain the closing bracket plus JSON
    # closers. Stop at the bracket; do not reject an otherwise valid point.
    match = re.match(r"\s*(\d+)\s*,\s*(\d+)\s*\]", text)
    if not match:
        return None
    point = [int(value) for value in match.groups()]
    return point if all(0 <= value < encoding.DISPLAY_SIZE for value in point) else None


def document_point(point, crop_size, top):
    """Invert the exact 1000-unit crop coordinate convention; never clamp."""
    return [point[0] * crop_size[0] / 1000, top + point[1] * crop_size[1] / 1000]


def choose_window(windows, weights):
    """Complete greedy coordinate-string likelihood with the mainline window prior."""
    valid = [i for i, window in enumerate(windows) if window["coordinate"] is not None]
    if not valid:
        return None
    # No candidate membership, browser success, or labels enter this decision.
    return max(valid, key=lambda i: windows[i]["log_probability"] + weights[i])


@torch.inference_mode()
def greedy_coordinate(processor, model, model_row, suffix, max_tokens=24):
    """Use the same split-prefix BF16 prefill as the saved Ownership scores."""
    with torch.autocast("cuda", dtype=torch.bfloat16):
        data = encoding.encode(processor, model_row, COORDINATE_CACHE_PREFIX)
        result = model(**data, use_cache=True, logits_to_keep=1)
        prefix_tokens = int(data["input_ids"].shape[1]) + len(suffix)
        result = model(
            input_ids=torch.tensor([suffix], device="cuda"),
            past_key_values=result.past_key_values, use_cache=True, logits_to_keep=1,
        )
        del data
        ids, log_probability, stopped = [], 0.0, False
        eos = processor.tokenizer.eos_token_id
        for _ in range(max_tokens):
            logits = result.logits[0, -1].float()
            token = int(logits.argmax())
            log_probability += float(logits[token] - torch.logsumexp(logits, -1))
            ids.append(token)
            text = processor.tokenizer.decode(ids, skip_special_tokens=False)
            if "]" in text or token == eos:
                stopped = True
                break
            result = model(
                input_ids=torch.tensor([[token]], device="cuda"),
                past_key_values=result.past_key_values, use_cache=True, logits_to_keep=1,
            )
        del result
    return {
        "tail": text, "token_ids": ids, "coordinate": parse_coordinate_tail(text),
        "log_probability": log_probability, "prefix_tokens": prefix_tokens,
        "stopped": stopped,
    }


def aggregate_hits(windows, hits, weights, bias):
    """Keep unassigned mass and apply the same window prior and tail bias as Ownership."""
    masses = defaultdict(list)
    for window, hit, weight in zip(windows, hits, weights):
        if hit['candidate_index'] is not None:
            masses[int(hit['candidate_index'])].append(window['log_probability'] + weight)
    scores = {str(i): logsumexp_values(values) + bias.get(i, 0.) for i, values in masses.items()}
    winner = min(masses, key=lambda i: (-scores[str(i)], i)) if masses else None
    return dict(candidate_index=winner, candidate_log_scores=scores)

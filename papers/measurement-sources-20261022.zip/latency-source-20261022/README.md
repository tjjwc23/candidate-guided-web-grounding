# 耗时测量源码快照

这 5 份源码用于核对 `outputs/ch04_submission_controls_20261022/latency_v2/protocol.json` 中的源码摘要，不参与活动训练或推理，也不是可直接运行的独立项目。

文件平铺存放；`provenance.json` 以原始仓库路径为键，记录当前文件名、原始 SHA-256 和恢复来源。复核脚本按该映射检查原始字节，再用当前 18D 评分器重算缓存决策。

从 StepEngine 根目录运行：

```bash
PYTHONPATH=src ../.venv/bin/python papers/verify_submission_latency.py
```

原始测量协议、样本和结果仍在原实验目录，不因快照迁移而修改。

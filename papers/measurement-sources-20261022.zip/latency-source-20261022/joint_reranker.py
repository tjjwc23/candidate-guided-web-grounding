"""Current 18-feature element fusion for full-width coordinate windows."""

import math
from collections import Counter

import torch
from torch import nn

from grounding.coordinate.bbox import log_sigmoid
from grounding.coordinate.overlap import proposal_info
from grounding.coordinate.regions import logsumexp_values


FEATURE_NAMES = [
    'semantic_logit', 'semantic_logweight', 'proposal_rank', 'proposal_tail',
    'candidate_log_evidence', 'hit_window_fraction', 'smallest_hit_fraction',
    'coordinate_logp', 'coordinate_mean_logp', 'coordinate_tokens',
    'window_logprior', 'window_document_top', 'crop_page_height',
    'bbox_crop_width', 'bbox_crop_height', 'bbox_crop_logarea',
    'point_bbox_edge_margin', 'point_bbox_center_distance',
]


def features(row, points, logits):
    """Use label-free evidence; smallest-box membership is a feature, never a filter."""
    assert points['action_key'] == row['action_key']
    assert len(logits) == len(row['candidate_bboxes']) <= 50
    assert len(points['windows']) == len(row['windows'])
    assert all(p['top'] == w['top'] for p, w in zip(points['windows'], row['windows']))
    hits, _, _ = proposal_info(row, points)
    ids = sorted(hits)
    boxes = row['candidate_bboxes']
    by_window = {}
    for i, support in hits.items():
        for hit in support:
            by_window.setdefault(hit['window'], []).append(i)
    native_counts = Counter(min(choices, key=lambda i: (boxes[i][2]*boxes[i][3], i))
                            for choices in by_window.values())
    counts = [len(w['centres']) for w in row['windows']]
    priors = [math.log(n / sum(counts)) for n in counts]
    pw, ph = row['page_size']
    assert all(p['crop_size'][0] == pw for p in points['windows']), 'Full-width windows required'
    matrix, base_scores = [], []
    for i in ids:
        support = hits[i]
        evidence = logsumexp_values([v['evidence'] for v in support])
        x, y, w, h = boxes[i]
        observations, weights = [], []
        for hit in support:
            p = hit['prediction']; cw, ch = p['crop_size']; px, py = hit['point']
            tokens = max(1, len(p['token_ids']))
            observations.append([
                p['log_probability']/10, p['log_probability']/tokens, tokens/24,
                priors[hit['window']], p['top']/ph, ch/ph,
                w/cw, h/ch, math.log(w*h/(cw*ch))/4,
                min((px-x)/cw, (x+w-px)/cw, (py-y)/ch, (y+h-py)/ch),
                ((px-x-w/2)/w)**2 + ((py-y-h/2)/h)**2,
            ])
            weights.append(math.exp(hit['evidence']-evidence))
        average = [sum(weight*v[j] for weight, v in zip(weights, observations))
                   for j in range(len(observations[0]))]
        matrix.append([
            logits[i]/10, log_sigmoid(logits[i])/4, i/50, float(i >= 20),
            evidence/10, len(support)/len(points['windows']),
            native_counts[i]/len(points['windows']), *average,
        ])
        base_scores.append(evidence + log_sigmoid(logits[i]))
    assert all(len(v) == len(FEATURE_NAMES) and all(math.isfinite(x) for x in v)
               for v in matrix)
    return dict(index=row['index'], action_key=row['action_key'], task_id=row['task_id'],
                partition=row.get('partition', 'test'), candidate_ids=ids,
                candidate_count=len(boxes), features=matrix, base_scores=base_scores,
                fallback=max(range(len(logits)), key=lambda i: (logits[i], -i)))


class JointReranker(nn.Module):
    """18 → 40 → 40 → 1 shared residual network, 2,440 parameters."""

    def __init__(self):
        super().__init__()
        self.correction = nn.Sequential(
            nn.Linear(len(FEATURE_NAMES), 40), nn.ReLU(),
            nn.Linear(40, 40), nn.ReLU(), nn.Linear(40, 1, bias=False))
        nn.init.zeros_(self.correction[-1].weight)

    def forward(self, batch):
        residual = self.correction(batch['features']).squeeze(-1).double()
        return (batch['base_scores'] + residual).masked_fill(~batch['valid'], -1e9)


class LinearReranker(JointReranker):
    """Same 18 inputs and base scores, with a linear residual."""

    def __init__(self):
        nn.Module.__init__(self)
        self.correction = nn.Linear(len(FEATURE_NAMES), 1, bias=False)
        nn.init.zeros_(self.correction.weight)


def collate(rows, device, labels=None, task_counts=None):
    width = max(1, max(len(row['candidate_ids']) for row in rows))
    batch = dict(features=torch.zeros(len(rows), width, len(FEATURE_NAMES), device=device),
                 base_scores=torch.zeros(len(rows), width, dtype=torch.float64, device=device),
                 valid=torch.zeros(len(rows), width, dtype=torch.bool, device=device))
    if labels is not None:
        batch['positive'] = torch.zeros(len(rows), width, dtype=torch.bool, device=device)
    for bi, row in enumerate(rows):
        n = len(row['candidate_ids'])
        if not n:
            continue
        batch['features'][bi, :n] = torch.tensor(row['features'], device=device)
        batch['base_scores'][bi, :n] = torch.tensor(row['base_scores'], dtype=torch.float64, device=device)
        batch['valid'][bi, :n] = True
        if labels is not None:
            batch['positive'][bi, :n] = torch.tensor(
                [bool(labels[row['action_key']][i]) for i in row['candidate_ids']], device=device)
    if task_counts is not None:
        batch['task_weight'] = torch.tensor([1./task_counts[row['task_id']] for row in rows], device=device)
    return batch


def ranking_loss(model, batch):
    assert batch['positive'].any(1).all(), 'Ranking gradients require a supported positive'
    scores = model(batch)
    losses = scores.logsumexp(1) - scores.masked_fill(~batch['positive'], -1e9).logsumexp(1)
    return (losses*batch['task_weight']).sum()/batch['task_weight'].sum()


@torch.no_grad()
def predict(model, rows, device):
    predictions, records = {}, []
    for start in range(0, len(rows), 128):
        chunk = rows[start:start+128]
        scores = model(collate(chunk, device)).cpu().tolist()
        for row, values in zip(chunk, scores):
            ids = row['candidate_ids']
            position = max(range(len(ids)), key=lambda j: (values[j], -ids[j])) if ids else None
            winner = ids[position] if ids else row['fallback']
            predictions[row['action_key']] = winner
            records.append(dict(index=row['index'], action_key=row['action_key'], winner=winner,
                                candidate_ids=ids, semantic_recovery=not bool(ids),
                                candidate_log_scores={str(i): values[j] for j, i in enumerate(ids)}))
    return predictions, records

# 覆盖率测量源码快照

`submission_coverage.py` 保留测量时的原始字节，用于校验 `outputs/ch04_submission_controls_20261022/coverage/protocol.json` 中的 `script_sha256`。原始路径与摘要见 `provenance.json`。该快照不作为活动入口。

当前测量入口为 `papers/submission_coverage.py`，复核入口为 `papers/verify_submission_coverage.py`。原始测量数据保持不变。
